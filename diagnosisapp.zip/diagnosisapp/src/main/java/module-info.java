module com.jdbc.diagnosisapp {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;

    requires com.dlsc.formsfx;

    opens com.jdbc.diagnosisapp to javafx.fxml;
    exports com.jdbc.diagnosisapp;
}