package com.jdbc.diagnosisapp;

import javafx.fxml.FXML;
import javafx.scene.control.*;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class DiagnosisController {
    @FXML
    private TextField patientIdField;
    @FXML
    private TextField symptomsField;
    @FXML
    private TextField diagnosisField;
    @FXML
    private TextField medicinesField;
    @FXML
    private CheckBox wardRequiredCheck;
    @FXML
    private TableView<Diagnosis> tableView;
    @FXML
    private Label nameLabel;

    private Connection connect() {
        String url = "jdbc:mysql://localhost:3306/diagnosisdata";
        Connection conn = null;
        try {
            conn = DriverManager.getConnection(url, "root", "123456");
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return conn;
    }

    @FXML
    private void handleSearch() {
        String patientId = patientIdField.getText();
        String sql = "SELECT * FROM diagnosis WHERE patient_id = ?";
        try (Connection conn = this.connect();
             PreparedStatement pstmt  = conn.prepareStatement(sql)){
            pstmt.setString(1, patientId);
            ResultSet rs  = pstmt.executeQuery();
            while (rs.next()) {
                // Add data to the table view
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    @FXML
    private void handleSave() {
        String patientId = patientIdField.getText();
        String symptoms = symptomsField.getText();
        String diagnosis = diagnosisField.getText();
        String medicines = medicinesField.getText();
        boolean wardRequired = wardRequiredCheck.isSelected();

        String sql = "INSERT INTO diagnosis(patient_id, symptoms, diagnosis, medicines, ward_required) VALUES(?, ?, ?, ?, ?)";
        try (Connection conn = this.connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, patientId);
            pstmt.setString(2, symptoms);
            pstmt.setString(3, diagnosis);
            pstmt.setString(4, medicines);
            pstmt.setBoolean(5, wardRequired);
            pstmt.executeUpdate();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    @FXML
    private void handleClose() {
        System.exit(0);
    }
}
